#!/bin/system/bash

#//Web Admin Scanner//
#//Coded by 000000//
#//!Please dont recode this script//


#//Variable setup//

domain() {
cat config.db | grep "Domain" | awk '{print $2}'
}

verbose() {
cat config/db/verbose
}

method() {
cat config/db/method
}

path(){
cat config/db/path
}

response() {
cat config/db/response
}

timeout() {
cat config/db/timeout
}

#//Set Target//

function set_domain() {
	
    printf "$menu" | awk '{print $3}' > config.txt
    printf "Domain: $(cat config.txt)" >| config.db
    rm config.txt
    printf "[+] Domain => $(domain) \n"
    
}


#//Set Path//

function set_path() {
		printf "$menu" | awk '{print $3}' > config/db/path
		printf "[+] path => $(path)\n"
}

#//Set verbose//

function set_verbose() {
		printf "$menu" | awk '{print $3}' > config/db/verbose
		printf "[+] verbose => $(verbose)\n"
}

#//Set method//

function set_method() {
		printf "$menu" | awk '{print $3}' > config/db/method
		printf "[+] method => $(method)\n"
}
#//Set Response//

function set_response() {
		printf "$menu" | awk '{print $3}' > config/db/response
		printf "[+] response => $(response)\n"
}

#//Set Timeout//

function set_timeout() {
		printf "$menu" | awk '{print $3}' > config/db/timeout
		printf "[+] timeout => $(timeout)\n"
}


#//Main Menu @(Home)//

function main() {
while IFS= read -e -p $'xdb = \e[1;32mweb admin\e[0m > ' menu; do
history -s "$menu"

  #//Default Commands//
  
  if [[ $menu == "clear" ]]; then
	 clear
    elif [[ $menu == "back" ]]; then
    exit
    
    elif [[ $menu == "help"* ]] ||
    	 [[ $menu == "show"* ]] ||
		 [[ $menu == "about"* ]]; then
    	 msg
    
    elif [[ $menu == "set domain"* ]]; then
    set_domain
    elif [[ $menu == "run" ]]; then
    init
    elif [[ $menu == "pwd" ]]; then
    pwd



	#//Configurations//
	
	elif [[ $menu == "set verbose"* ]]; then
		 set_verbose
	
    elif [[ $menu == "set method "* ]]; then
    	 set_method
   
    elif [[ $menu == "set path"* ]]; then
    	 set_path
    
    elif [[ $menu == "set response"* ]]; then
    	 set_response
    
    elif [[ $menu == "set timeout"* ]]; then
     	set_timeout
    
    else
    main
  fi
done
}




#//Set Verbose//

function verbose_get_config() {
	if [[ $(printf "$menu" | grep "on") ]]; then
	   printf "[+] verbose => ON\n"
			verbose=ON
		elif [[ $(printf "$menu" | grep "off") ]]; then
			printf "[+] verbose => OFF\n"
			verbose=OFF
		else
		main
	fi
}

#//Set Method//

function method_get_config() {
	if [[ $(printf "$menu" | grep "headers" ) ]]; then
		method="headers"
		printf "[+] Method => $(method)\n"
		elif [[ $(printf "$menu" | grep "search engine" ) ]]; then
			method="search engine"
			printf "[+] Method => $(method)\n"
		else
		main
	fi
}


#//Initializing (Run the script)//

function init() {

		printf " \n"
		
		TARGETBAR="$(domain)"
		
		BAR="$(echo $TARGETBAR | sed 's/./-/g')"
		
		printf " ---------$BAR\n"
		printf " [+] URL: $(domain)\n"
		printf " ---------$BAR\n"
		printf " \n"
    
	if [[ $(verbose) == ON ]]; then verbose_on
		elif [[ $(verbose) == OFF ]]; then verbose_off
		else main
	fi
}


#// IF VERBOSE OFF//

function verbose_off() {

	
	if [[ $(method) == "headers" ]]; then
		
		
		printf "\e[0;34m[*] \e[0mStarted $(date +%D) $(date +%T).\n"
		sleep 1
		
		printf "\e[0;34m[*] \e[0mChecking website headers response.\n"
			
			if [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '200 OK') ]]; then
				printf "\e[0;32m[+] \e[0m$(domain): Headers response \e[0;32m200 OK\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '404 Not Found') ]]; then
					printf "\e[0;91m[-] \e[0m$(domain): Headers response \e[0;91m404 Not Found\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '301 Moved') ]]; then
					printf "\e[0;32m[+] \e[0m$(domain): Headers response \e[0;32m301 Moved Permanently\e[0m\n"
				elif [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '302 Found') ]]; then
					printf "\e[0;32m[+] \e[0m$(domain): Headers response \e[0;32m302 Found\e[0m\n"
				else
				printf "\e[0;91m[-] Not detected\e[0m\n"
			fi
		
			printf "\e[0;34m[+] \e[0mChecking available file as worldlist\n"
			sleep 1
				if [[ $(cat $(path)) ]]; then
					printf "\e[0;32m[+] \e[0mFile exist!\n"
					printf "\e[0;34m[+] \e[0mPerforming brute-scan with (\e[1;32m$(path)\e[0m)\n"
					sleep 1
		
		
						for i in $(cat $(path)); do
						bar
							if [[ $(curl -s -I --max-time $(timeout) $(domain)/$i | grep "$response" ) ]]; then
								printf "\n\e[0;32m[+] FOUND \e[0;36m $(domain)/$i\n"
								sleep 0.8
					
					
								else
								bar
							fi
						
						done
						printf "\n"
					else
					
						printf "\e[0;91m[!] Can't found file as worldlist\n"
						sleep 0.8
						printf "\e[0;91m[!] Quitting!\e[0m\n"
						sleep 1
				fi
				
			
		
		printf "\e[0;34m[*] \e[0mScanning completed\n"
	fi
	exit
}

#// PROGGRESS SECTION @(Verbose On)//

function bar() {
	echo -ne ' \r' &
    printf "\e[1;32m[+] \e[0mProcessing $(nl -v1 $(path) | grep "$i"  | head -c 6) /$(wc -l $(path))"
}

#// IF VERBOSE ON //

function verbose_on() {

	if [[ $(method) == "headers" ]]; then
		
		
		
			
			if [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '200 OK') ]]; then
				printf "\e[0;32m[+] \e[0m$(domain): Headers response \e[0;32m200 OK\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout)  $(domain) | grep '404 Not Found') ]]; then
					printf "\e[0;91m[-] \e[0m$(domain): Headers response \e[0;91m404 Not Found\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '301 Moved') ]]; then
					printf "\e[0;32m[+] \e[0m$(domain): Headers response \e[0;32m301 Moved Permanently\e[0m\n"
				elif [[ $(curl -s -i --max-time $(timeout) $(domain) | grep '302 Found') ]]; then
					printf "\e[0;32m[+] \e[0m$(domain): Headers response \e[0;32m302 Found\e[0m\n"
				else
				printf "\e[0;91m[-] Not detected\e[0m\n"
			fi
		
			
					printf "\e[0;34m[+] \e[0mPerforming brute-scan with (\e[1;32m$(path)\e[0m)\n"
					
		
		
						for i in $(cat $(path)); do
						
							if [[ $(curl -s -I --max-time $(timeout) $(domain)/$i | grep "200 OK" ) ]]; then
								printf "\n\e[0;36m[+] \e[0m $(domain)/$i \e[1;32m200 OK\e[0m\n"
								
								elif [[ $(curl -s -I --max-time $(timeout) $(domain)/$i | grep "301" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $(domain)/$i \e[1;32m301\e[0m\n"
								elif [[ $(curl -s -I --max-time $(timeout) $(domain)/$i | grep "302" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $(domain)/$i \e[1;32m302\e[0m\n"
								elif [[ $(curl -s -I --max-time $(timeout) $(domain)/$i | grep "404" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $(domain)/$i \e[1;32m404\e[0m\n"
							
							fi
						
						done
						printf "\n"
				
			
		
		printf "\e[0;34m[+] \e[0mDone\n"
	fi
	exit

}



#// ATTRIBUTES //

function opt() {
	
			printf "\n"
			printf " -------------------\n"
			printf " [+] Current options\n"
			printf " -------------------\n\n"
			printf " - Domain        : $(domain)\n"
			printf " - Verbose       : $(verbose)\n"
			printf " - Wordlist      : $(path)\n"
			printf " - Response      : $(response)\n"
			printf " - Method        : $(method)\n"
			printf " - Timeout       : $(timeout)\n"
			printf "\n"
}

function msg() {

	if [[ $menu == "help" ]]; then

		printf "\n"
		printf " --------------------\n"
		printf " [+] Default commands\n"
		printf " --------------------\n\n"
		printf " - clear               Clear the terminal\n"
		printf " - help                Show a help message\n"
		printf " - exit                Exit the framework\n"
		printf "\n"
		printf " --------------------\n"
		printf " [+] Modules commands\n"
		printf " --------------------\n\n"
		printf " - show modules        Display all available modules\n"
		printf " - use <module>        Use the selected module\n"
		printf " - set <opt>           Set the option of module\n"
		printf " - show options        Display the module's options\n"
		printf " - run                 Execute the module\n"
		printf " - back                Exit from the module\n"
		printf "\n"
		printf " --------------------\n"
		printf " [+] Options commands\n"
		printf " --------------------\n\n"
		printf " - install             Install script from source\n"
		printf " - about               Display about this framework\n"
		printf "\n"

	   elif [[ $menu == "show modules" ]]; then
	
			printf "\n"
			printf " --------------------\n"
			printf " [+] Modules database\n"
			printf " --------------------\n\n"
			printf " - web admin           Brute-scan admin panel\n"
			printf " - web content         Dump to find content manager system\n"
			printf " - web page            Print all links from target\n"
			printf " - web privacy         High rate database plugin\n"
			printf "\n"
			printf " - net user/proxy      Config your proxy\n"
			printf " - net user/port       Advanced proxy configurating\n"
			printf " - net ip/user         Print your public ip\n"
			printf " - net ip/trace        Traceroute target ip\n"
			printf " - net config          All network configuration\n"  
			printf "\n"
			printf " - act ddos            DDOS attack plugin\n"
			printf " - act bypass          DDOS attack plugin\n"
			printf "\n"
			printf " ---------------------\n"
			printf " [+] Modules total: 11\n"
			printf " ---------------------\n"
			printf "\n"
	
		elif [[ $menu == "show options" ]]; then
			opt
 
		elif [[ $menu == "about" ]]; then
		
			printf " \n"
			printf " ------------------\n"
			printf " [+] Module profile\n"
			printf " ------------------\n\n"
			printf " - Name          : web admin\n"
			printf " - Author        : R-Eight™\n"
			printf " - File          : db/web-admin-panel\n"
			printf " - Location      : src/modules/\n"
			printf " - Object        : Finding\n"
			printf " - Type          : Scanners\n"
			printf " - Lenguage      : BASH\n"
			printf " \n"
			printf " ----------------\n"
			printf " [+] Requirements\n"
			printf " ----------------\n\n"
			printf " - curl\n"
			printf " - wget\n"
			printf " \n"
	  else
	   printf "[-] $menu : Command not found\n"
	fi

}
opt
main