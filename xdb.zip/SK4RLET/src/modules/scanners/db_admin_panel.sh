#!/bin/system/bash

#//Web Admin Scanner//
#//Coded by 000000//
#//!Please dont recode this script//


#//Variable setup//

target() {
cat config/db/target
}

verbose() {
cat config/db/verbose
}

method() {
cat config/db/method
}

path(){
cat config/db/path
}

response() {
cat config/db/response
}

timeout() {
cat config/db/timeout
}

#//Main Menu @(Home)//

function main() {
while IFS= read -e -p $'xdb [\e[1;32mdb/admin/panel\e[0m] > ' menu; do
history -s "$menu"

  #//Default Commands//
  
  if [[ $menu == "clear" ]]; then
	 clear
    elif [[ $menu == "back" ]]; then
    exit
    elif [[ $menu == "show options" ]]; then
    show_opt
    elif [[ $menu == "set target"* ]]; then
    set_target
    elif [[ $menu == "run" ]]; then
    init
    elif [[ $menu == "help" ]]; then
    help
    elif [[ $menu == "pwd" ]]; then
    pwd



	#//Configurations//
	
	elif [[ $menu == "set verbose"* ]]; then
		 set_verbose
	
    elif [[ $menu == "set method "* ]]; then
    	 set_method
   
    elif [[ $menu == "set path"* ]]; then
    	 set_path
    
    elif [[ $menu == "set response"* ]]; then
    	 set_response
    
    elif [[ $menu == "set timeout"* ]]; then
     	set_timeout
    
    else
    main
  fi
done
}


#//Set Target//

function set_target() {
	
		printf "$menu" | awk '{print $3}' > config/db/target
    	printf "[+] target => $(target)\n"
}


#//Set Path//

function set_path() {
		printf "$menu" | awk '{print $3}' > config/db/path
		printf "[+] path => $(path)\n"
}

#//Set verbose//

function set_verbose() {
		printf "$menu" | awk '{print $3}' > config/db/verbose
		printf "[+] verbose => $(verbose)\n"
}

#//Set method//

function set_method() {
		printf "$menu" | awk '{print $3}' > config/db/method
		printf "[+] method => $(method)\n"
}
#//Set Response//

function set_response() {
		printf "$menu" | awk '{print $3}' > config/db/response
		printf "[+] response => $(response)\n"
}

#//Set Timeout//

function set_timeout() {
		printf "$menu" | awk '{print $3}' > config/db/timeout
		printf "[+] timeout => $(timeout)\n"
}

#//Set Verbose//

function verbose_get_config() {
	if [[ $(printf "$menu" | grep "on") ]]; then
	   printf "[+] verbose => ON\n"
			verbose=ON
		elif [[ $(printf "$menu" | grep "off") ]]; then
			printf "[+] verbose => OFF\n"
			verbose=OFF
		else
		main
	fi
}

#//Set Method//

function method_get_config() {
	if [[ $(printf "$menu" | grep "headers" ) ]]; then
		method="headers"
		printf "[+] Method => $(method)\n"
		elif [[ $(printf "$menu" | grep "search engine" ) ]]; then
			method="search engine"
			printf "[+] Method => $(method)\n"
		else
		main
	fi
}


#//Initializing (Run the script)//

function init() {

    
	if [[ $(verbose) == ON ]]; then verbose_on
		elif [[ $(verbose) == OFF ]]; then verbose_off
		else main
	fi
}


#// IF VERBOSE OFF//

function verbose_off() {

	
	if [[ $(method) == "headers" ]]; then
		
		
		printf "\e[0;34m[+] \e[0mStarted $(date +%D) $(date +%T) \e[0m\n"
		sleep 1
		
		printf "\e[0;34m[+] \e[0mChecking website headers response\n"
			
			if [[ $(curl -s -i --max-time $(timeout) $(target) | grep '200 OK') ]]; then
				printf "\e[0;32m[+] \e[0m$(target): Headers response \e[0;32m200 OK\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout) $(target) | grep '404 Not Found') ]]; then
					printf "\e[0;91m[-] \e[0m$(target): Headers response \e[0;91m404 Not Found\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout) $(target) | grep '301 Moved') ]]; then
					printf "\e[0;32m[+] \e[0m$(target): Headers response \e[0;32m301 Moved Permanently\e[0m\n"
				elif [[ $(curl -s -i --max-time $(timeout) $(target) | grep '302 Found') ]]; then
					printf "\e[0;32m[+] \e[0m$(target): Headers response \e[0;32m302 Found\e[0m\n"
				else
				printf "\e[0;91m[-] Not detected\e[0m\n"
			fi
		
			printf "\e[0;34m[+] \e[0mChecking available file as worldlist\n"
			sleep 1
				if [[ $(cat $(path)) ]]; then
					printf "\e[0;32m[+] \e[0mFile exist!\n"
					printf "\e[0;34m[+] \e[0mPerforming brute-scan with (\e[1;32m$(path)\e[0m)\n"
					sleep 1
		
		
						for i in $(cat $(path)); do
						bar
							if [[ $(curl -s -I --max-time $(timeout) $(target)/$i | grep "$response" ) ]]; then
								printf "\n\e[0;32m[+] FOUND \e[0;36m $(target)/$i\n"
								sleep 0.8
					
					
								else
								bar
							fi
						
						done
						printf "\n"
					else
					
						printf "\e[0;91m[!] Can't found file as worldlist\n"
						sleep 0.8
						printf "\e[0;91m[!] Quitting!\e[0m\n"
						sleep 1
						main
				fi
				
			
		
		printf "\e[0;34m[+] \e[0mDone\n"
	fi
}

#// PROGGRESS SECTION @(Verbose On)//

function bar() {
	echo -ne ' \r' &
    printf "\e[1;32m[+] \e[0mProcessing $(nl -v1 $(path) | grep "$i"  | head -c 6) /$(wc -l $(path))"
}

#// IF VERBOSE ON //

function verbose_on() {

	if [[ $(method) == "headers" ]]; then
		
		
		printf "\e[0;34m[+] \e[0mStarted $(date +%D) $(date +%T) \e[0m\n"
		sleep 1
		
		printf "\e[0;34m[+] \e[0mChecking website headers response\n"
			
			if [[ $(curl -s -i --max-time $(timeout) $(target) | grep '200 OK') ]]; then
				printf "\e[0;32m[+] \e[0m$(target): Headers response \e[0;32m200 OK\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout)  $(target) | grep '404 Not Found') ]]; then
					printf "\e[0;91m[-] \e[0m$(target): Headers response \e[0;91m404 Not Found\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $(timeout) $(target) | grep '301 Moved') ]]; then
					printf "\e[0;32m[+] \e[0m$(target): Headers response \e[0;32m301 Moved Permanently\e[0m\n"
				elif [[ $(curl -s -i --max-time $(timeout) $(target) | grep '302 Found') ]]; then
					printf "\e[0;32m[+] \e[0m$(target): Headers response \e[0;32m302 Found\e[0m\n"
				else
				printf "\e[0;91m[-] Not detected\e[0m\n"
			fi
		
			
					printf "\e[0;34m[+] \e[0mPerforming brute-scan with (\e[1;32m$(path)\e[0m)\n"
					
		
		
						for i in $(cat $(path)); do
						
							if [[ $(curl -s -I --max-time $(timeout) $(target)/$i | grep "200 OK" ) ]]; then
								printf "\n\e[0;36m[+] \e[0m $(target)/$i \e[1;32m200 OK\e[0m\n"
								
								elif [[ $(curl -s -I --max-time $(timeout) $(target)/$i | grep "301" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $(target)/$i \e[1;32m301\e[0m\n"
								elif [[ $(curl -s -I --max-time $(timeout) $(target)/$i | grep "302" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $(target)/$i \e[1;32m302\e[0m\n"
								elif [[ $(curl -s -I --max-time $(timeout) $(target)/$i | grep "404" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $(target)/$i \e[1;32m404\e[0m\n"
							
							fi
						
						done
						printf "\n"
				
			
		
		printf "\e[0;34m[+] \e[0mDone\n"
	fi

}



#// ATTRIBUTES //

function show_opt() {
    printf "\n"
    printf "\e[1;32m"
    printf " Current options\e[0m\n"
    printf " ===============\n\n"
	printf " [+] Target       : $(target)\n"
	printf " [+] Verbose      : $(verbose)(ON/OFF)\n"
	printf " [+] Path list    : $(path)\n"
	printf " [+] Method       : $(method)\n"
	printf " [+] Timeout      : $(timeout)\n"
	printf " [+] Response     : $(response)\n"

}






function help() {
printf "\n"
printf "\e[1;32m"
printf " Core commands\e[0m\n"
printf ' =============\n\n'
printf " clear              Clear the terminal\n"
printf " help               Show a help message\n"
printf " set                Set the value\n"
printf " show               Show the value\n"
printf " exit               Exit this framework\n"
printf "\n"
printf "\e[1;32m"
printf " Modules commands\e[0m\n"
printf " ================\n\n"
printf " show modules       Display all available modules\n"
printf " use <module>       Use the selected module\n"
printf " set <opt>          Set the option of module\n"
printf " show options       Display the module's options\n"
printf " run                Execute the module\n"
printf " back               Exit from the module\n"
printf "\e[1;32m"
printf " Resources commands\e[0m\n"
printf " ==================\n\n"
printf " show recources     Display all available recources\n"
printf " <recources name>   Use the selected resource\n"
printf " set <opt>          Set the option of resource\n"
printf " show options       Display the resource's options\n"
printf " run                Execute the resource\n"
printf " back               Exit from the resource\n"
printf "\n"
printf "\e[1;32m"
printf " More commands\e[0m\n"
printf " =============\n\n"
printf " install            Install script from source\n"
printf " about              Display about this framework\n"

printf "\n"
}

main