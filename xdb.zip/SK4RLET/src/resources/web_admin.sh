#!/bin/system/bash

#//Web Admin Scanner//
#//Coded by 000000//
#//!Please dont recode this script//


#//Variable setup//

target=$(cat target.txt)
verbose=OFF
method="headers"
path="list.txt"
response="200"
timeout="5"

#//Main Menu @(Home)//

function main() {
while IFS= read -e -p $'xdb \e[1;37m[\e[1;32mweb admin\e[1;37m]\e[0m > ' menu; do
history -s "$menu"

  #//Default Commands//
  
  if [[ $menu == "clear" ]]; then
	 clear
    elif [[ $menu == "exit" ]]; then
    exit
    elif [[ $menu == "show options" ]]; then
    show_opt
    elif [[ $menu == "set target" ]]; then
    set_target
    elif [[ $menu == "run" ]]; then
    init
    elif [[ $menu == "help" ]]; then
    help
    elif [[ $menu == "options" ]]; then
    options
    elif [[ $menu == "pwd" ]]; then
    pwd



	#//Configurations//
	
	elif [[ $menu == "verbose on" ]] ||
 		[[ $menu == "verbose off" ]]; then
	 	verbose_get_config
	
    elif [[ $menu == "method headers" ]] ||
         [[ $menu == "method search engine" ]]; then
   	  method_get_config
   
    elif [[ $menu == "set path" ]]; then
    	 set_path
    
    elif [[ $menu == "set response" ]]; then
    	set_response
    elif [[ $menu == "set timeout" ]]; then
    	set_timeout
    else
    main
  fi
done
}


#//Set Target//

function set_target() {
	
		read -p $'[+] Target: ' target
    	printf "$target" > target.txt
}


#//Set Path//

function set_path() {
		read -p $'[+] Path: ' path
}

#//Set Response//

function set_response() {
		read -p $'[+] Response: ' response
		
}

#//Set Timeout//

function set_timeout() {
		read -p $'[+] Timeout: ' timeout
}

#//Set Verbose//

function verbose_get_config() {
	if [[ $(printf "$menu" | grep "on") ]]; then
	   printf "[+] verbose => ON\n"
			verbose=ON
		elif [[ $(printf "$menu" | grep "off") ]]; then
			printf "[+] verbose => OFF\n"
			verbose=OFF
		else
		main
	fi
}

#//Set Method//

function method_get_config() {
	if [[ $(printf "$menu" | grep "headers" ) ]]; then
		method="headers"
		printf "[+] Method => $method\n"
		elif [[ $(printf "$menu" | grep "search engine" ) ]]; then
			method="search engine"
			printf "[+] Method => $method\n"
		else
		main
	fi
}


#//Initializing (Run the script)//

function init() {

    
	if [[ $verbose == ON ]]; then verbose_on
		elif [[ $verbose == OFF ]]; then verbose_off
		else main
	fi
}


#// IF VERBOSE OFF//

function verbose_off() {

	
	if [[ $method == "headers" ]]; then
		
		
		printf "\e[0;34m[+] \e[0mStarted $(date +%D) $(date +%T) \e[0m\n"
		sleep 1
		
		printf "\e[0;34m[+] \e[0mChecking website headers response\n"
			
			if [[ $(curl -s -i --max-time $timeout $target | grep '200 OK') ]]; then
				printf "\e[0;32m[+] \e[0m$target: Headers response \e[0;32m200 OK\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $timeout $target | grep '404 Not Found') ]]; then
					printf "\e[0;91m[-] \e[0m$target: Headers response \e[0;91m404 Not Found\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $timeout $target | grep '301 Moved') ]]; then
					printf "\e[0;32m[+] \e[0m$target: Headers response \e[0;32m301 Moved Permanently\e[0m\n"
				elif [[ $(curl -s -i --max-time $timeout $target | grep '302 Found') ]]; then
					printf "\e[0;32m[+] \e[0m$target: Headers response \e[0;32m302 Found\e[0m\n"
				else
				printf "\e[0;91m[-] Not detected\e[0m\n"
			fi
		
			printf "\e[0;34m[+] \e[0mChecking available file as worldlist\n"
			sleep 1
				if [[ $(cat $path) ]]; then
					printf "\e[0;32m[+] \e[0mFile exist!\n"
					printf "\e[0;34m[+] \e[0mPerforming brute-scan with (\e[1;32m$path\e[0m)\n"
					sleep 1
		
		
						for i in $(cat $path); do
						bar
							if [[ $(curl -s -I --max-time $timeout $target/$i | grep "$response" ) ]]; then
								printf "\n\e[0;32m[+] FOUND \e[0;36m $target/$i\n"
								sleep 0.8
					
					
								else
								bar
							fi
						
						done
						printf "\n"
					else
					
						printf "\e[0;91m[!] Can't found file as worldlist\n"
						sleep 0.8
						printf "\e[0;91m[!] Quitting!\e[0m\n"
						sleep 1
						main
				fi
				
			
		
		printf "\e[0;34m[+] \e[0mDone\n"
	fi
}

#// PROGGRESS SECTION @(Verbose On)//

function bar() {
	echo -ne ' \r' &
    printf "\e[1;32m[+] \e[0mProcessing $(nl -v1 $path | grep "$i"  | head -c 6) /$(wc -l $path)"
}

#// IF VERBOSE ON //

function verbose_on() {

	if [[ $method == "headers" ]]; then
		
		
		printf "\e[0;34m[+] \e[0mStarted $(date +%D) $(date +%T) \e[0m\n"
		sleep 1
		
		printf "\e[0;34m[+] \e[0mChecking website headers response\n"
			
			if [[ $(curl -s -i --max-time $timeout $target | grep '200 OK') ]]; then
				printf "\e[0;32m[+] \e[0m$target: Headers response \e[0;32m200 OK\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $timeout  $target | grep '404 Not Found') ]]; then
					printf "\e[0;91m[-] \e[0m$target: Headers response \e[0;91m404 Not Found\e[0m\n"
			
				elif [[ $(curl -s -i --max-time $timeout $target | grep '301 Moved') ]]; then
					printf "\e[0;32m[+] \e[0m$target: Headers response \e[0;32m301 Moved Permanently\e[0m\n"
				elif [[ $(curl -s -i --max-time $timeout $target | grep '302 Found') ]]; then
					printf "\e[0;32m[+] \e[0m$target: Headers response \e[0;32m302 Found\e[0m\n"
				else
				printf "\e[0;91m[-] Not detected\e[0m\n"
			fi
		
			
					printf "\e[0;34m[+] \e[0mPerforming brute-scan with (\e[1;32m$path\e[0m)\n"
					
		
		
						for i in $(cat $path); do
						
							if [[ $(curl -s -I --max-time $timeout $target/$i | grep "200 OK" ) ]]; then
								printf "\n\e[0;36m[+] \e[0m $target/$i \e[1;32m200 OK\e[0m\n"
								
								elif [[ $(curl -s -I --max-time $timeout $target/$i | grep "301" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $target/$i \e[1;32m301\e[0m\n"
								elif [[ $(curl -s -I --max-time $timeout $target/$i | grep "302" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $target/$i \e[1;32m302\e[0m\n"
								elif [[ $(curl -s -I --max-time $timeout $target/$i | grep "404" ) ]]; then
									printf "\n\e[0;36m[+] \e[0m $target/$i \e[1;32m404\e[0m\n"
							
							fi
						
						done
						printf "\n"
				
			
		
		printf "\e[0;34m[+] \e[0mDone\n"
	fi

}



#// ATTRIBUTES //

function show_opt() {
if [[ $verbose == OFF ]]; then
    printf "\n"
    printf "\e[1;32m"
    printf " Current options\e[0m\n"
    printf " ===============\n\n"
	printf " [+] Target       : $target\n"
	printf " [+] Source       : web/admin\n"
	printf " [+] Verbose      : $verbose\n"
	printf " [+] Path list    : $path\n"
	printf " [+] Method       : $method\n"
	printf " [+] Response     : $response\n"
	printf " [+] Timeout      : $timeout\n"
	printf "\n"
elif [[ $verbose == ON ]]; then
    printf "\n"
    printf "\e[1;32m"
    printf " Current options\e[0m\n"
    printf " ===============\n\n"
	printf " [+] Target       : $target\n"
	printf " [+] Source       : web/admin\n"
	printf " [+] Verbose      : $verbose\n"
	printf " [+] Path list    : $path\n"
	printf " [+] Method       : $method\n"
	printf " [+] Timeout      : $timeout\n"
	printf "\n"
fi

}






function help() {
	printf "\n"
	printf "\e[1;32m"
	printf " Resource commands\e[0m\n"
	printf ' ================\n\n'
	printf " clear                 clear the terminal\n"
	printf " set target            set the target\n"
	printf " show options          display current settings\n"
	printf "\n"
	printf " verbose on            set output to verbose mode\n"
	printf " verbose off           set output to non-verbose mode\n"
	printf "\n"
	printf " method headers        set method with headers response\n"
	printf " method se             set method with search engine\n"
	printf "\n"
	printf " set path              set path of the worldlist\n"
	printf " set response          set the headers response\n"
	printf " set timeout           set the max time waiting\n"
	printf "\n"
	printf " run                   run this source\n"
	printf " help                  display this message\n"
	printf " about                 show about this source\n"
	printf " exit                  exit this source\n"
	printf "\n"
}

main