#!/bin/system/bash

#//Web CMS Scanner//
#//Coded by [Bgsprtm]//
#//!Please dont recode this script//


#//Variable setup//

target=$(cat target.txt)


#//Main Menu @(Home)//

function main() {
while IFS= read -e -p $'config\e[1;37m [\e[1;32mweb content\e[1;37m]\e[0m > ' menu; do
history -s "$menu"

  #//Default Commands//
  
  if [[ $menu == "clear" ]]; then
	 clear
    elif [[ $menu == "exit" ]]; then
    exit
    elif [[ $menu == "show options" ]]; then
    show_opt
    elif [[ $menu == "set target" ]]; then
    set_target
    elif [[ $menu == "run" ]]; then
    init
    elif [[ $menu == "help" ]]; then
    help
    elif [[ $menu == "pwd" ]]; then
    pwd



	#//Configurations//
	
	elif [[ $menu == "verbose on" ]] ||
 		[[ $menu == "verbose off" ]]; then
	 	verbose_get_config
	
    elif [[ $menu == "method headers" ]] ||
         [[ $menu == "method search engine" ]]; then
   	  method_get_config
   
    elif [[ $menu == "set path" ]]; then
    	 set_path
    
    elif [[ $menu == "set response" ]]; then
    	set_response
    
    else
    main
  fi
done
}


#//Set Target//

function set_target() {
	
		read -p $'[+] Target: ' target
    	printf "$target" > target.txt
}



#//Initializing (Run the script)//

function init() {

	printf "\e[0;34m[+]\e[0m Started at $(date +%H)\n"
	printf "\e[0;34m[+]\e[0m Dump target using \e[1;32mwget\e[0m\n"
		if [[ $(wget -qO- --timeout=5 $target | grep 'wp-content') ]]; then
			printf "\e[0;32m[+] \e[0mWp-content detected\n"
			else
			printf "\e[0;91m[!] Wp-Content not detected!\e[0m\n"
		fi
}




#// ATTRIBUTES //

function show_opt() {

    printf "\n"
    printf "\e[1;32m"
    printf " Current options\e[0m\n"
    printf " ===============\n\n"
	printf " [+] Target       : $target\n"
	printf " [+] Source       : web/admin\n"
	printf "\n"


}






function help() {
	printf "\n"
	printf "\e[1;32m"
	printf " Resource commands\e[0m\n"
	printf ' =================\n\n'
	printf " clear                 clear the terminal\n"
	printf " set target            set the target\n"
	printf " show options          display current settings\n"
	printf "\n"
	printf " engine lynx           set engine with lynx command\n"
	printf " verbose off           set output to non-verbose mode\n"
	printf "\n"
	printf " method headers        set method with headers response\n"
	printf " method se             set method with search engine\n"
	printf "\n"
	printf " set path              set path of the worldlist\n"
	printf " set response          set the headers response\n"
	printf "\n"
	printf " run                   run this source\n"
	printf " help                  display this message\n"
	printf " about                 show about this source\n"
	printf " exit                  exit this source\n"
	printf "\n"
}

main