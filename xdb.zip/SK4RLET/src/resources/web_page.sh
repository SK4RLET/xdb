#!/bin/system/bash

#//Web Admin Scanner//
#//Coded by 000000//
#//!Please dont recode this script//


#//Variable setup//

target=$(cat target.txt)

#//Main Menu @(Home)//

function main() {
while IFS= read -e -p $'config\e[1;37m [\e[1;32mweb page\e[1;37m]\e[0m > ' menu; do
history -s "$menu"

  #//Default Commands//
  
  if [[ $menu == "clear" ]]; then
	 clear
    elif [[ $menu == "exit" ]]; then
    exit
    elif [[ $menu == "show options" ]]; then
    show_opt
    elif [[ $menu == "set target" ]]; then
    set_target
    elif [[ $menu == "run" ]]; then
    init
    elif [[ $menu == "help" ]]; then
    help




	#//Configurations//
	
    
    else
    main
  fi
done
}


#//Set Target//

function set_target() {
	
		read -p $'[+] Target: ' target
    	printf "$target" > target.txt
}


#//Set Path//

#//Initializing (Run the script)//

function init() {
	
	printf "\n"
	printf "~#//Starting http requests.. ($target)\n"
	
		if [[ $(lynx --dump --listonly --nonumbers $target) ]]; then

			lynx --dump --listonly --nonumbers $target | grep -v 'Hidden links:' > page.config
			
	
			cat page.config | grep -v 'Visible links:' > page_output.config
			rm page.config
	
			cat page_output.config | sort | uniq > page.config
			rm page_output.config
			
				printf "\n"
				printf "\e[1;32m"
					printf " Information Page\e[0m\n"
					printf " ================\n\n"
			
				for i in $(cat page.config); do
			
   				 
		    		printf " [+] Page    : \e[0;32m$i\n"
						curl -s -I --max-time 5 $i | grep "HTTP" | awk '{print " \033[0m[+] Response:\033[0m",$0}'
					printf "\n"
		
				done
					cp page.config page
					printf " \e[1;32m[+] \e[0m$(wc -l page) links was found\n"
					cp page $target.txt
					rm page.config && rm page
					printf " \e[1;32m[+] \e[0mFile saved as \e[0m$target.txt\n\n"
					
			else
			printf " \e[1;91m* HTTP REQUEST BAD RESPONSE!\e[0m\n\n"
		fi
}




#// ATTRIBUTES //

function show_opt() {
    printf "\n"
    printf "\e[1;32m"
    printf " Current options\e[0m\n"
    printf " ===============\n\n"
	printf " [+] Target       : $target\n"
	printf " [+] Source       : web/page\n"
	
	printf "\n"

}






function help() {
	printf "\n"
	printf "\e[1;32m"
	printf " Resource commands\e[0m\n"
	printf ' =================\n\n'
	printf " clear                 clear the terminal\n"
	printf " set target            set the target\n"
	printf " show options          display current settings\n"
	printf "\n"
	printf " run                   run this source\n"
	printf " help                  display this message\n"
	printf " about                 show about this source\n"
	printf " exit                  exit this source\n"
	printf "\n"
}

main